#!/bin/sh
volumePath=$1
resourcePath=$2
cp -R "$resourcePath/Software Update Patch Toggle.app" "$volumePath/Applications/Utilities/"