#!/bin/sh
rsrcPath=$1
volPath=$2
specPath=$3
rm "$volPath/System/Installation/Packages"
cp -R "/Volumes/OS X Install ESD/Packages" "$volPath/System/Installation/"
cp "/Volumes/OS X Install ESD/BaseSystem.dmg" "$volPath/"
cp "/Volumes/OS X Install ESD/BaseSystem.chunklist" "$volPath/"
cp "$rsrcPath/InstallableMachines.plist" "$volPath/System/Installation/Packages/"
cp "$rsrcPath/PlatformSupport.plist" "$volPath/System/Library/CoreServices/"
cp "$rsrcPath/prelinkedkernel" "$volPath/System/Library/PrelinkedKernels/"
cp -R "$rsrcPath/LegacyUSBInjector.kext" "$volPath/Library/Extensions/"
chown -R 0:0 "$volPath/Library/Extensions/LegacyUSBInjector.kext"
chmod -R 0755 "$volPath/Library/Extensions/LegacyUSBInjector.kext"
cp -R "$rsrcPath/macOS Post Install.app" "$volPath/Applications/Utilities/"
cp "$rsrcPath/InstallerMenuAdditions.plist" "$volPath/System/Installation/CDIS/macOS Installer.app/Contents/Resources/"
cp "$specPath/OSInstall.mpkg" "$volPath/System/Installation/Packages/"
cp "$rsrcPath/prelinkedkernel" "$volPath/Applications/Utilities/macOS Post Install.app/Contents/Resources/"
cp -R "$rsrcPath/OSInstaller.framework" "$volPath/System/Library/PrivateFrameworks/"